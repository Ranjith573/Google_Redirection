from django.shortcuts import render,redirect

# Create your views here.
def google(request):

    return redirect('https://google.com/')