from django.apps import AppConfig


class RedirectConfig(AppConfig):
    name = 'redirect'
